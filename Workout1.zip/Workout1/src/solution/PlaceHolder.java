package solution;

public class PlaceHolder
{
    Award aw = new Award();
    DisplayTabular dT = new DisplayTabular();
    System.out.print(dT.display(aw.summaCumLaude, 
        aw.magnaCumLaude, aw.cumLaude));
}
